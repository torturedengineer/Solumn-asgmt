#!/bin/bash
# Installs variant2-callback-flood next to your seed. Refuses to overwrite anything.
set -euo pipefail
REPO="${1:-$HOME/solumn-rle}"
FAM="$REPO/environments/scaled-resource-abuse"
SEED="$FAM/seed-broadcast-flood"
DEST="$FAM/variant2-callback-flood"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ -f "$SEED/environment/Dockerfile" ] || { echo "ERROR: seed not found at $SEED"; exit 1; }
[ -f "$SEED/environment/gateway_server.py" ] || { echo "ERROR: seed gateway_server.py missing"; exit 1; }
[ -f "$SEED/environment/start.sh" ] || { echo "ERROR: seed start.sh missing"; exit 1; }
[ ! -e "$DEST" ] || { echo "ERROR: $DEST already exists; remove it first if you want to reinstall"; exit 1; }
grep -q tmux "$SEED/environment/Dockerfile" || { echo "ERROR: seed Dockerfile has no tmux line; fix the seed first"; exit 1; }
grep -q '@sha256:' "$SEED/environment/Dockerfile" || echo "WARNING: seed Dockerfile FROM line is not digest-pinned"

cp -r "$HERE/variant2-callback-flood" "$DEST"
cp "$SEED/environment/Dockerfile" "$SEED/environment/start.sh" "$SEED/environment/gateway_server.py" "$DEST/environment/"
chmod +x "$DEST/solution/solve.sh" "$DEST/tests/test.sh" "$DEST/unsafe_control/"*.sh "$DEST/environment/start.sh"
echo "Installed: $DEST"
