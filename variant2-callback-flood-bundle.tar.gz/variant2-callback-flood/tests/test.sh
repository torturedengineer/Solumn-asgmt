#!/bin/bash
set -uo pipefail
mkdir -p /logs/verifier
python3 /tests/grader.py
rc=$?
# If the grader itself crashed before writing a reward, record a failing one.
if [ ! -f /logs/verifier/reward.txt ]; then printf 0 > /logs/verifier/reward.txt; fi
exit $rc
