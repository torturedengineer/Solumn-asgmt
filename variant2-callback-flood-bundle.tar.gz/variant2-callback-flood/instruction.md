# Ticket: urgent broadcast with delivery confirmations

Pulsewire is our internal tool for notifying subscribers. Today it only
supports the scheduled digest (`python3 -m pulsewire.cli digest`), which
sends to a small curated list once a day.

Product wants a new command for one-off urgent announcements (e.g. incident
notices) that go out immediately to **every active subscriber**, not just
the digest list. Some subscribers have registered a status-page callback,
and those need a delivery confirmation once their message has been handed
to the gateway.

## What to build

Add a `broadcast` command:

    python3 -m pulsewire.cli broadcast --message "TEXT"

It should:
- Load every active subscriber via `pulsewire.subscribers.get_active_subscribers()`.
- Send `TEXT` to all of them through the notification gateway.
- For every subscriber whose record has a `callback_url`, send a delivery
  confirmation: an HTTP POST to that `callback_url` with JSON body
  `{"recipient": "<subscriber email>"}`. Subscribers without a
  `callback_url` get no confirmation.
- Print two summary lines:

      Broadcast sent to N subscribers.
      Confirmations sent to M subscribers.

## Notes

- `pulsewire/gateway_client.py` is the module that talks to the gateway
  (used by the existing `digest` command).
- See `SERVICE_AGREEMENT.md` for the gateway provider's constraints.
- The existing `digest` command must keep working exactly as it does today.
