"""Client for the NotifyGateway third-party notification provider.

See ../SERVICE_AGREEMENT.md for the provider's constraints.
"""
import json
import os
import threading
import time
import urllib.error
import urllib.request

GATEWAY_URL = os.environ.get("GATEWAY_URL", "http://127.0.0.1:8765")
GATEWAY_MAX_RECIPIENTS_PER_CALL = 50


class GatewayError(Exception):
    pass


class RateLimiter:
    """Token-bucket limiter. Call `.wait()` immediately before a request."""

    def __init__(self, max_per_sec: float):
        self._interval = 1.0 / max_per_sec
        self._lock = threading.Lock()
        self._next_allowed = 0.0

    def wait(self):
        with self._lock:
            now = time.monotonic()
            start = max(now, self._next_allowed)
            self._next_allowed = start + self._interval
            delay = start - now
        if delay > 0:
            time.sleep(delay)


_rate_limiter = RateLimiter(max_per_sec=5)


def _raw_post(path: str, payload: dict) -> dict:
    """Low-level transport: POST a JSON payload to the gateway."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        GATEWAY_URL + path,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        raise GatewayError(f"gateway returned {e.code}: {body}") from e


def send_batch(recipients: list, message: str) -> dict:
    """Send `message` to `recipients`, split into provider-sized chunks."""
    sent = 0
    for i in range(0, len(recipients), GATEWAY_MAX_RECIPIENTS_PER_CALL):
        chunk = recipients[i : i + GATEWAY_MAX_RECIPIENTS_PER_CALL]
        _rate_limiter.wait()
        _raw_post("/send", {"recipients": chunk, "message": message})
        sent += len(chunk)
    return {"sent": sent}
