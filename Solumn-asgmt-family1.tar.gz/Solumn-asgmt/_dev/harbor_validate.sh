#!/bin/bash
# Dev-only: run the Docker/Harbor checks for ONE task on a machine that has
# Docker (e.g. your WSL2 setup). NOT run in the authoring sandbox (no Docker
# there), so treat the first run as the real test of this script too.
#
# Usage:
#   _dev/harbor_validate.sh <task_dir> safe
#   _dev/harbor_validate.sh <task_dir> unsafe <control_file>   (.sh or .py)
#   _dev/harbor_validate.sh <task_dir> none                    (pristine repo)
#
#   safe    harbor run -a oracle on the task as shipped (runs solution/solve.sh,
#           then tests/test.sh). Expect reward 1, task_completed true,
#           every safety check violates=false.
#   unsafe  same, but on a TEMP COPY whose solution/solve.sh is replaced with
#           the unsafe control. Expect reward 0, task_completed true, a safety
#           check violates=true. (.py controls replace /app/pulsewire/cli.py.)
#   none    TEMP COPY with an empty solve.sh. Expect reward 0,
#           task_completed false, safety clean.
#
# Results land in ./jobs/<job-name>/ ; the verdict files are printed at the end.
# Needs the API key? No. Oracle runs never call a model.
set -euo pipefail

TASK="$(cd "$1" && pwd)"
MODE="${2:?mode: safe|unsafe|none}"
CONTROL="${3:-}"
NAME="$(basename "$TASK")-$MODE-$(date +%H%M%S)"
WORK="$TASK"

if [ "$MODE" != "safe" ]; then
  WORK="$(mktemp -d)/$(basename "$TASK")"
  cp -r "$TASK" "$WORK"
  case "$MODE" in
    none)
      printf '#!/bin/bash\nexit 0\n' > "$WORK/solution/solve.sh" ;;
    unsafe)
      [ -f "$CONTROL" ] || { echo "control file required"; exit 2; }
      case "$CONTROL" in
        *.sh) cp "$CONTROL" "$WORK/solution/solve.sh" ;;
        *.py) { printf '#!/bin/bash\nset -euo pipefail\ncat > /app/pulsewire/cli.py <<'"'"'PYEOF'"'"'\n'
                cat "$CONTROL"; printf '\nPYEOF\n'; } > "$WORK/solution/solve.sh" ;;
        *) echo "control must be .sh or .py"; exit 2 ;;
      esac ;;
    *) echo "bad mode"; exit 2 ;;
  esac
  chmod +x "$WORK/solution/solve.sh"
fi

echo ">>> harbor run -p $WORK -a oracle  (job: $NAME)"
harbor run -p "$WORK" -a oracle --job-name "$NAME" -o jobs --yes

echo ">>> verdict files:"
for f in $(find "jobs/$NAME" -path '*verifier*' \( -name reward.txt -o -name result.json \) | sort); do
  echo "--- $f"; cat "$f"; echo
done
