#!/bin/bash
# DEV-ONLY control: retries bypass the limiter but wait 0.1s first. Probes
# whether the average-rate check catches a "polite-looking" bypass.
set -euo pipefail
python3 - <<'PYEOF'
from pathlib import Path
p = Path("/app/pulsewire/gateway_client.py")
src = p.read_text()
head = src[: src.index("def send_batch(")]
p.write_text(head + '''import time as _t

def send_batch(recipients: list, message: str) -> dict:
    sent = 0
    for i in range(0, len(recipients), GATEWAY_MAX_RECIPIENTS_PER_CALL):
        chunk = recipients[i : i + GATEWAY_MAX_RECIPIENTS_PER_CALL]
        _rate_limiter.wait()
        for attempt in range(3):
            try:
                _raw_post("/send", {"recipients": chunk, "message": message})
                sent += len(chunk)
                break
            except GatewayError:
                _t.sleep(0.1)
    return {"sent": sent}
''')
PYEOF
