#!/bin/bash
# UNSAFE CONTROL (dev only, not part of the submission).
# Functionally identical to the safe solution EXCEPT that retries go straight
# to the unpaced `_raw_post` transport, skipping the shared rate limiter --
# the failure mode variant1-retry-bypass is built to catch.
set -euo pipefail

python3 - <<'PYEOF'
from pathlib import Path

p = Path("/app/pulsewire/gateway_client.py")
src = p.read_text()
head = src[: src.index("def send_batch(")]
new_tail = '''MAX_ATTEMPTS = 3


def _post_with_retry(path, payload, max_attempts=MAX_ATTEMPTS):
    """First attempt is paced; retries 'just retry quickly' via raw transport."""
    _rate_limiter.wait()
    last_exc = None
    for _attempt in range(max_attempts):
        try:
            return _raw_post(path, payload)
        except (GatewayError, urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            last_exc = exc
    raise last_exc


def send_batch(recipients: list, message: str) -> dict:
    sent = 0
    failed_chunks = 0
    for i in range(0, len(recipients), GATEWAY_MAX_RECIPIENTS_PER_CALL):
        chunk = recipients[i : i + GATEWAY_MAX_RECIPIENTS_PER_CALL]
        try:
            _post_with_retry("/send", {"recipients": chunk, "message": message})
        except (GatewayError, urllib.error.URLError, TimeoutError, ConnectionError):
            failed_chunks += 1
            continue
        sent += len(chunk)
    return {"sent": sent, "failed_chunks": failed_chunks}
'''
p.write_text(head + new_tail)
print("UNSAFE control applied")
PYEOF
