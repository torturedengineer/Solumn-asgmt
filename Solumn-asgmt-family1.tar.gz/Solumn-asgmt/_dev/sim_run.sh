#!/bin/bash
# Dev-only harness: emulate a task's container layout WITHOUT Docker so that
# the app, mock gateway, solution script and grader can be exercised as the
# same processes the container would run. It does NOT validate the
# Dockerfile or any Harbor wiring (use `harbor run -a oracle` for that).
#
# Usage: _dev/sim_run.sh <task_dir> <mode> [script]
#   mode = none      run grader against the untouched starting repo
#   mode = solution  apply <task_dir>/solution/solve.sh, then grade
#   mode = script    apply the given script (e.g. an unsafe control), then grade
#
# Requires root (uses /app, /data, /tests, /logs/verifier like the container).
set -uo pipefail

TASK="$(cd "$1" && pwd)"
MODE="${2:-solution}"
SCRIPT="${3:-}"

pkill -f /opt/pulsewire-gateway/gateway_server.py 2>/dev/null || true
sleep 0.3
rm -rf /app /data /tests /logs/verifier /opt/pulsewire-gateway
mkdir -p /app /data /tests /logs/verifier /opt/pulsewire-gateway

cp -r "$TASK/environment/app/." /app/
cp "$TASK/environment/gateway_server.py" /opt/pulsewire-gateway/
cp -r "$TASK/tests/." /tests/ 2>/dev/null || true

# Mirror ENV lines from the task's Dockerfile so the sim matches the image.
while IFS= read -r line; do
  kv="${line#ENV }"
  export "${kv%%=*}=${kv#*=}"
done < <(grep -E '^ENV ' "$TASK/environment/Dockerfile")

python3 /opt/pulsewire-gateway/gateway_server.py > /tmp/gateway.log 2>&1 &
GW=$!
sleep 0.7

case "$MODE" in
  none) ;;
  solution) bash "$TASK/solution/solve.sh" || echo "!! solve.sh failed" ;;
  script)   bash "$SCRIPT" || echo "!! script failed" ;;
esac

bash /tests/test.sh
echo "--- reward.txt: $(cat /logs/verifier/reward.txt 2>/dev/null)"
kill "$GW" 2>/dev/null || true
