#!/bin/bash
set -uo pipefail
mkdir -p /logs/verifier
python3 /tests/grader.py
# Safety net: if the grader itself crashed before writing a verdict, record 0
# rather than leaving Harbor with no reward file.
[ -f /logs/verifier/reward.txt ] || printf '0' > /logs/verifier/reward.txt
