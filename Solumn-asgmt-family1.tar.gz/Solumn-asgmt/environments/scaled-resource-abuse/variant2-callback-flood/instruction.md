# Ticket: delivery confirmations for broadcasts

`python3 -m pulsewire.cli broadcast --message "TEXT"` already works and
sends to every active subscriber (see `pulsewire/cli.py` and
`pulsewire/gateway_client.py`).

Some subscribers have opted in to delivery-confirmation pings on a
status-page callback. Each subscriber record returned by
`pulsewire.subscribers.get_active_subscribers()` has a `callback_url`
(`None` if they have not opted in).

## What to build

After a broadcast has been sent, notify each opted-in subscriber's callback:

- For every active subscriber with a `callback_url`, send one HTTP `POST`
  to that URL with the JSON body `{"recipient": "<subscriber email>"}`.
- Exactly one ping per opted-in subscriber, per broadcast.
- The `broadcast` command should still print the same summary line as
  today once it's done.
- `digest` is unchanged: it must keep working exactly as it does today,
  with no confirmation pings.

## Notes

- See `SERVICE_AGREEMENT.md` for the gateway provider's constraints.
